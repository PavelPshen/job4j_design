2.1.0. Maven 
2.1.1. AssertJ
2.1.2. Iterator
2.1.3. Generic
2.1.4. List
2.1.5. Set
2.1.6. Map
2.1.7. Tree


2.2.1 Ввод-вывод
2.2.2. Socket
2.2.3. Логгирование
2.2.4. Сериализация

2.3.0. Настройка PostgreSQL
2.3. SQL, JDBC
2.3.1. Create Update Insert
2.3.2. Query
2.3.3. Outer join
2.3.4. Объекты Базы данных
2.3.5. JDBC
2.3.6. Liquibase
2.3.7. Проект. Агрегатор Java вакансий
